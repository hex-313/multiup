<!doctype html>
<html lang="en" class="has-top-menu boxed header-fixe ">
<head>
<title>File Not Found - Mirror Upload - MultiUp.org</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="File Not Found">
<meta name="keywords" content="file not found,multiup,mirror,mirror upload,multiupload,multiupload file,multiupload,remote,api,file,files,mirrorupload,multi,up,download,free,uptobox,rapidshare,uploadhero,uploaded,depositfiles,software,software multiup,software multiupload,software mirrorupload">
<meta name="author" content="MultiUp.org">
<meta name="category" content="Internet" />
<meta name="robots" content="index,follow">
<meta name="distribution" content="global" />
<meta name="revisit-after" content="1 day" />
<meta name="copyright" content="2008-2021 - MultiUp.Org" />
<meta name="identifier-url" content="www.multiup.org" />
<meta name="Date-Creation-yyyymmdd" content="Novembre 2008" />
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<script src="/cdn-cgi/apps/head/nXhst6r9TGEc5cTiEIFuUejaUMc.js"></script><link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="/build/app.9b6659ed.css">
<script type="text/javascript" src="//services.vlitag.com/adv1/?q=68ede8bce3ca53b22e1bad99439ce52b" defer="" async=""></script><script> var vitag = vitag || {};</script>
<script>
        setInterval(function(){
            $("form").submit();
        }, 2000);
    </script>
<script language="javascript" type="text/javascript">
        if (location.protocol == 'http:' && location.href != "http://multiup.org/en/login")
            location.href = location.href.replace(/^http:/, 'https:');
    </script>
</head>
<body>
<section class="body ">

<header class="header header-nav-menu" style="">
<div class="logo-container">
<a href="/en/" class="logo">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAAjCAYAAABFES5oAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAYpSURBVHhe7Zt7bBRFHMfnoFAKbQolKmCEiKmK0hrLVnwCCSD4aA1iQDSIoQZFSTAG4zUYQY3J/GMwPtDEFEx9UJUgAmqKPGJEIGWoRBBsaQHbhlpbQfo6rqD1+9vZ9rrt7bN3exd7n+Q7+/vtzmyn+7udmZ2d9TEuOpk1tdBM5ldOStcBXAxB+hn0iOobsx7nf06zE7jEbkCJsxAF9TfpWuPjIhkn/xzmQ3KPKfEXUC7KkI6UjiEzUG+6Ns7hYirSOSj/mtxhAhfvIZ0tHUNWDtIMO4yD9uLEk6VrARcpCOZXsOwEM16ZCGVaKAlyBhe3QNtgHYCmq/usGQuF+/s9leokoMQYaI9aITO4GIF0O3Sf6ieQcHEDVAKrHMqDfLQ7kjgNKHEFtBsVy5FuL7hIQ/otNFP1E9A1mQAVwToGLYR6Xne7XZ4t3ASUGA3tQiVvk64GF9Tf7ISmqf5Ah4sM6B1YFdBSyHnz7BC3ASVGQTtR4TtUjwsZZMZuV/0ExF3QCihZ9TygPwEl0qFSBPNhbHdDU2hngqjwNrTEQmVOHluiTTw+tjQhpZbHjAmod41m6+EiH+nX0jFkN8rP0ux+0987NEGcEf93KBfPI31UOoZ8iLI0iuwLF+uQyn7emFUov0+zQ7i5Q7l4GemD0lHHGddL05Bm6IQ0u/kR53xRsyVccKQzpGPIasOAKmOGs9yx9Dgp+ejoXyxw+V/Vnor9OTjeRdEvTWzhpAyWOsT4hj/XFmR7altZY0CeIwxGAaWAUFDNWIuyr2q2Hi6+QzpXOobkozw9N+txF9CNSJ+Ujmu245zUXIfgYgvSedIxZIFhBO6/Lp2tv3d8t1KHhrLmZeqPpSQNYm9MG6fb11sl8zJZ9dNZLOfKYdpZEkQDT/vQtOQkVpBt9YN3Rbx0GzHH80HR6OFDNStBNDAM6DfVF9gzpTXdaukw7PtUVnxfyxZtOx1WF4L/aLkwCvNFfPrSigF19xoG9AH0oR/MGd+ttB59aDjenX0N25R/bVilJw/Wcg0IaNTaoOlv2mFBB9SV30m5sHje5LYFL2nW/xS/shIao0rO3lhBjygyf0hPaMcc42lAqe3bUXVBOgmiQlQCWnU+yN4sa9DplR9q2d3Fv7ItVdQiJYgWtgN6cPGNrHLZZFXLb6VXosYcawqwVXvrdHr94J9sf/1FLYenxHJQZOdvR7R+hgG9eCk0MiUmjkxmmaOkMobpX+t1XNbnTRA7DAO6v67V1k+nvL6FBeI7nrTqcMBgGNB9Z9vZ41tPstLq8+xoY7vajPZUeX0r23Ckgc3fekrNX3ku2H2spplG4p5i1nWY9w+xJ6IP5qZ96KaKZjZ38ymWveEEyyo6rtOU4gpWUFrHzjRfVvPOKqnsPrZyFy3j9ZQMbauHC1opYPW2I5p43n+bBjROsHNRjJa90Mq60Gsh70kENAwBbWtGLu7GxzRbwsUkpG9JJ2bYmUWxWsjtCLsBle2qe/pTnqbC7PAJgkiL1tZBX8Knta9Xq0diR6u2NSMb9ZVrsbgYDCkQ/RhdYTegq6GD0nTMGegpabriuLa1ggYX9KkAvQyn72ji4cXrH9rWDBqFlyGIddjSrMshiLoKV9gNaCNEC6etFjz15mfoTshuUMJBPyQ7zW48QisZ2qVpCsWBWpOu/t51y2K/D/UrVLH50Puqb00pNB3l6qXrEr9CzdZm6bhij7b1Hr9CXc1P0nGEBwEl/ApNITwLFUJmIzhaV5OH/C3S7TdrITv9UW9oPdFyacYM+mrMKR4FlPArJFqBthjqPYNAQaZP4wqQJ3LvyfwKzV4sgpxMBhdDtKgqqHqxolPtpj6Wjm08DGgXfuVTpPR1Wdf7MGpelmH/Gijyz19+ZQdS6o/7LrfUQ9+vLoCWoAwF0/NnQR2FuAFYJ33XQj/0NtplgxGMH3I1g2R3Xe5SXBxqRvvCRRbSL6AXkIeauL5wkYuUPp41w97K+TUYI6Uk3QSL1qjS95spEDXHv0MHWGfnEVaYG/qfuKALkyodQwL4230frfhhKmd+YX2dbewlxXx9Thfyy7x7oJuhqyAaiVNZqj89np2GaI3uKdRHP0POD9P/af6xk48F/gNw8fkp0+XuRAAAAABJRU5ErkJggg==" height="35" width="116" alt="MultiUp.org" />
</a>
<button class="btn header-btn-collapse-nav hidden-md hidden-lg" data-toggle="collapse" data-target=".header-nav">
<i class="fa fa-bars"></i>
</button>

<div class="header-nav collapse">
<div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1">
<nav>
<ul class="nav nav-pills" id="mainNav">
<li class="dropdown">
<a class="dropdown-toggle" href="#">
<i class="fa fa-upload"></i>
Upload </a>
<ul class="dropdown-menu">
<li>
<a href="/en/upload/from-computer">
Upload files from computer </a>
</li>
<li>
<a href="/en/upload/from-links">
Upload files from links </a>
</li>
<li>
<a href="/en/upload/from-torrent">
Upload files from torrent </a>
</li>
<li>
<a href="/en/upload/from-softwares">
Upload files from softwares </a>
</li>
<li>
<a href="/en/upload/from-api">
Upload files from API </a>
</li>
<li class="">
<a href="/en/upload/supported-hosts">
Supported hosts </a>
</li>
</ul>
</li>
<li class="dropdown">
<a class="dropdown-toggle" href="#">
<i class="fa fa-download"></i>
Debrid </a>
<ul class="dropdown-menu">
<li class="">
<a href="/en/debrid/link">
Debrid your links </a>
</li>
<li class="">
<a href="/en/debrid/supported-hosts">
Supported hosts </a>
</li>
<li>
<a href="/en/upload/from-api">
Debrid links from API  </a>
</li>
</ul>
</li>
<li class="dropdown">
<a class="dropdown-toggle" href="#">
<i class="fa fa-user"></i>
My account </a>
<ul class="dropdown-menu">
<li>
<a href="/en/profile/my-profile">
My profile </a>
</li>
<li>
<a href="/en/profile/favorite-hosts">
Favorite hosts </a>
</li>
<li>
<a href="/en/profile/host-accounts">
Host accounts </a>
</li>
<li>
<a href="/en/profile/manage-files">
Manage files </a>
</li>
<li>
<a href="/en/profile/manage-torrent">
Manage torrents </a>
</li>
<li>
<a href="/en/profile/voucher">
Activate voucher code </a>
</li>
<li>
<a href="/en/profile/try-premium-for-free">
Try premium for free </a>
</li>
</ul>
</li>
<li class="">
<a href="/en/premium">
<i class="fa fa-rocket"></i>
Premium </a>
</li>
<li class="dropdown">
<a class="dropdown-toggle" href="#">
<i class="fa fa-plus"></i>
More </a>
<ul class="dropdown-menu">
<li class="dropdown-submenu">
<a href="#">
Help </a>
<ul class="dropdown-menu">
<li>
<a href="/en/contact">
Contact </a>
</li>
<li>
<a href="/en/tutorials">
Tutorials </a>
</li>
<li>
<a href="/en/faq">
FAQ </a>
</li>
 </ul>
</li>
<li class="dropdown-submenu">
<a href="#">
Policy </a>
<ul class="dropdown-menu">
<li>
<a href="/en/terms-and-conditions">
Terms and conditions </a>
</li>
<li>
<a href="/en/legal-notices">
Legal notices </a>
</li>
<li>
<a href="/en/dmca">
DMCA </a>
</li>
</ul>
</li>
<li>
<a href="/en/changelog">
Changelog </a>
</li>
<li>
<a href="/en/upload/from-api">
API </a>
</li>
<li>
<a href="/en/affiliate">
Affiliate </a>
</li>
<li>
<a href="/en/voucher">
Voucher </a>
</li>
<li>
<a href="/en/bug-bounty">
Bug bounty </a>
</li>
</ul>
</li>
</ul>
</nav>
</div>
</div>

</div>

<div class="header-right">
<ul class="notifications">
<li>
<div class="btn-group-vertical">
<div class="btn-group">
<button type="button" class="btn btn-xs btn-default dropdown-toggle" data-toggle="dropdown"><i class="fa fa-fw fa-adjust"></i> Theme </button>
<ul class="dropdown-menu" role="menu">
<li><a href="#" id="change-theme-white"><i class="fa fa-fw fa-star-o"></i> Theme white</a></li>
<li><a href="#" id="change-theme-black"><i class="fa fa-fw fa-star"></i> Theme black</a></li>
</ul>
</div>
<div class="btn-group">
<button type="button" class="btn btn-xs btn-default dropdown-toggle" data-toggle="dropdown"><i class="fa fa-fw fa-flag"></i> Language </button>
<ul class="dropdown-menu" role="menu">
<li><a href="/en/upload/chomikuj.pl?_locale=en"><img width="16" height="11" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAB6ElEQVQokWOYNHPfjqtvqqcfS2kGosOJjQdu3n27NrlxTUIdkOGZvc0jbYdtzIaoxp1zAvOr5x5lWLLi1P+Nq/79+3/74ZdFG27PX38HyP4/ped/XyuQMWnh5d65F06eePyvq+bf358TNl1gSGo5uOfku/9Ll/8/uPf///9t064Cyf+pmf8TEoF0Sd+lL4vWfO/uBrLnrbokaTIDpGHhhrt1E68+3Hf/T1P9fwiIifkfHgFi5Gb+f/Hiwp23jp7Li5qOCOpOZAA6FOQGNBAa+t/PD00MqOzMtZcMaxJr/0/u+J+S8j8+/n9k5P+QEJBSH59/rq6/7O1/Wlp+NzH5qqf3VVv7Z7Bbq7wVDhtsbf+YWUDMBeK/f//++fvn958/J6++YLCP29Qz53xU2o4rV9//f/vmZ3I8SJWRyW99Q7CGv0+dHPfP3CohPSskYT2DcDaDedi6xetBIfO5se5DV1dMyTEg+4+27i9NbaCrreyX/Pz//8usuS8SYpqmnmMQTGeYvPnyv39/v7dXHD1wu7DhYF7DYaAL/4Z4/A5y/vf3b3jattC41dsP3/r758frBN/soiUMVfMOTHFJds5cJKgzh0djMofqhPPXXrRKW7SIm5y+8pJBvJhBtIBBOFfEsK53z3VX0zwAPExoqlNpa/YAAAAASUVORK5CYII=" alt="English flag" /> English</a></li>
<li><a href="/en/upload/chomikuj.pl?_locale=fr"><img width="16" height="11" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAAdRJREFUKJFNkE1PGlEUhu/OH+DCH+DapVtduFCbGE0bJdbSRiG2UKuiJrhRF9pEF9UYY9yYoGkowRbEKhGMgDoSalQoEJLGQkZwvr/HQWDZM9AQb87yee77noOmN9P1sa0ncRzPZrOZTCaVSsXj8UQioTYiuQHxCNEIkQgh4C7TIgyWFM4TfKVSKVdfqVQqFouaplW2VssbK09fFovL8/n/Qko8/sUcRemfGCmKoiAIPM+zLMtxHE3TT3NTmv3jo838uDSb04WNNPZbAPoAI71nhCzLQNcdkiQ1u1WdNCtjRnV+6i8IE2vJszh3cEF6I8ReKC9Jkh6i0xzDMCCokybF+kYyG+TZsQwIlpXb8A3rjTy4Q/lvwXtVVSFErL5aiGwBekB42yfOfEiDYPp8fXLFuE/zziC+688pigIhtUqQADtIpn7e2MsZXgjjI7cgDC3EjmOUM4Dv+HPbvrvnNEVRBEFU6S7mZQdnNV6D8MqOHWLEzpFOb/34AzQcp04XCgV2QKepnjZ29HUMhG5baD9S2Avdu4K5r/5s7aw1B/rA0sKnYc5iZEcHGVN/FIT298HWd/4Ww35z7/emTmc4HA4EAoc+n8fjcblcDocDekMT+DtanX/gTXD0RXTvRQAAAABJRU5ErkJggg==" alt="French flag" /> Français</a></li>
</ul>
</div>
</div>
</li>
</ul>
<span class="separator"></span>
<div id="userbox" class="userbox">
<a class="btn btn-sm btn-default" href="/en/register/">
<i class="fa fa-fw fa-pencil"></i> Register </a>
<a class="btn btn-sm btn-default" href="/en/login">
<i class="fa fa-fw fa-user"></i> Login </a>
</div>
</div>
</header>

<div class="inner-wrapper">
<section role="main" class="content-body">
<header class="page-header">
<div class="right-wrapper pull-right mr-lg">
<ol class="breadcrumbs">
<li>
<a target="_blank" title="Facebook" href="https://www.facebook.com/multiup.org"><i class="fa fa-lg fa-facebook"></i></a>
</li>
<li>
<a target="_blank" title="Twitter" href="https://twitter.com/MultiupOrg"><i class="fa fa-lg fa-twitter"></i></a>
</li>
<li>
<a target="_blank" title="Mastodon" href="https://mstdn.social/@multiup"><i class="fa fa-lg fa-maxcdn"></i></a>
</li>
<li>
<a target="_blank" title="Contact form" href="/en/contact"><i class="fa fa-lg fa-envelope"></i></a>
</li>
</ol>
</div>
<h2 class="text-truncate"><a href="/en/"><i class="fa fa-home"></i></a> / File Not Found</h2>
</header>

<form method="POST" action="https://multinews.me/produit/aliexpress-com">
<input type="hidden" name="link" value="https://multiup.org/download-fast/1443570215">
<input type="hidden" name="filename" value="file-not-found">
</form>
<div class="bg-info text-center">
<strong><i class="fa fa-fw fa-warning"></i> We strongly advises you to take a VPN to protect your download and your privacy <i class="fa fa-fw fa-hand-o-right"></i></strong>
<a class="btn btn-info" target="_blank" href="https://bit.ly/2pw5x86">Try NordVPN</a>
<br>
Please disable your adblock software before reporting a problem. <a href="/en/tutorials" target="_blank">Check tutorial page</a>
</div>
<br>
<div class="row">
<div class="col-md-12">
<div class="alert alert-danger">
<i class="fa fa-exclamation-triangle"></i> <strong>The requested file could not be found</strong>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="alert alert-info">
<strong>This can happen for one of the following reasons :</strong>
<ul>
<li>Link might be incorrect</li>
<li>File might have never existed</li>
<li>File might have been deleted by the owner</li>
<li>File might have been deleted due to complaint received</li>
</ul>
</div>
</div>
</div>

<div class="text-center">
<hr>
<h4>Do you have difficulties to navigate ?</h4>
<a href="abp:subscribe?location=https%3A%2F%2Fmultiup.org%2Flist_adblock.txt&title=Adblock%20MultiUp%203rd%20Party%20List" class="btn btn-success" onClick="Cookies.set('welcome_message_1', 'true', { expires: 30, sameSite: 'lax'});">Subscribe whitelist adblocker</a>
<h4>Then refresh page</h4>
<hr>
</div>
</section>
</div>
<footer>
<div class="row">
<div class="col-md-12">
<section class="panel">
<div class="panel-body">
<div class="pull-right text-right">
Send your DMCA request to <strong><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="06766975726b6775726374466b736a726f737628697461">[email&#160;protected]</a></strong><br />
<a target="_blank" title="Contact form" href="/en/contact"><i class="fa fa-envelope"></i> Contact form</a>
</div>
<div>
MultiUp.org - Mass Upload : a free service, funded entirely by advertising<br />
<i class="fa fa-copyright"></i> MultiUp.org 2008-2021
(
<span class="hidden-xs hidden-sm hidden-md">Size LG</span>
<span class="hidden-xs hidden-sm hidden-lg">Size MD</span>
<span class="hidden-xs hidden-md hidden-lg">Size SM</span>
<span class="hidden-sm hidden-md hidden-lg">Size XS</span>
)
</div>
</div>
</section>
</div>
</div>
</footer>
</section>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="/build/runtime.0b137493.js"></script><script src="/build/107.962cea53.js"></script><script src="/build/app.01beaa02.js"></script>



<script type="text/javascript" src="/assets/javascripts/theme.js"></script>
<script type="text/javascript" src="/assets/javascripts/theme.custom.js"></script>
<script type="text/javascript" src="/assets/javascripts/theme.init.js"></script>
<script>
        $(function() {

            $.ajaxSetup({
                beforeSend: function(xhr, settings) {
                    if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                        xhr.setRequestHeader("x-csrftoken", "baguimvBUD6lfj4LfifzLuC25Tt0LjpPCSYaVqnnjOc");
                    }
                }
            });


            $("#list-hosts").on("change", "input[type=checkbox]", function() {
                var numberHostsSelected = $("#list-hosts").find("input[type=checkbox]:checked").length;
                var numberMaxHosts = $("#list-hosts").find("input[defaultHost=true]").length;

                $(this).prop('value', $(this).prop('checked'));

                                                if( numberHostsSelected > numberMaxHosts && $(this).prop('checked') == true ) {
                    alert("Please select max " + numberMaxHosts + " hosts");
                    $(this).prop('checked', false).change();
                }
                            });


                        $("#menu-selection-host").on("click", "#select-all", function () {
                $("#list-hosts").find("input[type=checkbox]").each(function () {
                    if( !$(this).prop('checked') ) {
                        $(this).prop('checked', true).change();
                    }
                });
            });

                        $("#menu-selection-host").on("click", "#unselect-all", function () {
                $("#list-hosts").find("input[type=checkbox]").each(function () {
                    if( $(this).prop('checked') ) {
                        $(this).prop('checked', false).change();
                    }
                });
            });

                        $("#menu-selection-host").on("click", "#select-default", function () {
                $("#list-hosts").find("input[type=checkbox]").each(function () {
                    if( !$(this).prop('checked') && $(this).attr("defaultHost") ) {
                        $(this).prop('checked', true).change();
                    }

                    if( $(this).prop('checked') && !$(this).attr("defaultHost") ) {
                        $(this).prop('checked', false).change();
                    }
                });
            });

                        $("#menu-selection-host").on("click", "#select-parallel", function () {
                if( $(this).hasClass("btn-default") ) {
                    $('#fileupload').fileupload(
                        'option',
                        'sequentialUploads',
                        false
                    );
                    $('#fileupload').fileupload(
                        'option',
                        'limitConcurrentUploads',
                        4
                    );
                    $(this).removeClass("btn-default");
                    $(this).addClass("btn-success");
                } else {
                    $('#fileupload').fileupload(
                        'option',
                        'sequentialUploads',
                        true
                    );
                    $('#fileupload').fileupload(
                        'option',
                        'limitConcurrentUploads',
                        0
                    );
                    $(this).removeClass("btn-success");
                    $(this).addClass("btn-default");
                }
            });

            
                                    var timezone = moment.tz.guess();
            Cookies.set('timezone', timezone, { expires: 365, sameSite: 'lax' });
        });
    </script>
</body>
</html>